import express from "express";
import dotenv from "dotenv";
import cookieParser from "cookie-parser";
import cors from "cors";
dotenv.config();
import Razorpay from "razorpay"
const app= express();
const port=process.env.PORT;
import database from "./lib/database.js";

// export const instance= new Razorpay({
//   kay_id:process.env.RAZORPAY_KEY_ID,
//   key_secret:process.env.RAZORPAY_KEY_SECRET
// })

// removing the razorpay

import Accountrouter from "./routers/Account.js";
import Cart from "./routers/Addtocart.js";
import  Product from "./routers/Addproduct.js"
// import { addproduct } from "./controllers/Product.js";
import Listofproduct from "./routers/buy.js"
// import PaymentRouter from "./routers/Payment.js"



app.use(express.json());
app.use(cookieParser())
app.use(
    cors({
  origin: 'https://makhana-0nl6.onrender.com', 
  methods: ['GET', 'POST', 'PUT', 'DELETE'],
  credentials: true
})
)
app.use("/api/user",Accountrouter);
app.use("/api/cart",Cart);;
app.use("/api/",Product);
app.use("/api/cart",Listofproduct);
// app.use("/payment",PaymentRouter);



app.listen(port,()=>{
    database()
    console.log(`server is listeing at ${port}`)
})
